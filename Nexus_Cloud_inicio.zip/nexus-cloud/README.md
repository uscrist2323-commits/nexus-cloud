# Nexus Cloud — site inicial

Este projeto é uma página estática pronta para publicar no GitHub Pages.

## Publicar pelo Android
1. Abra https://github.com e entre na sua conta.
2. Toque em **+** e escolha **New repository**.
3. Nomeie o repositório `nexus-cloud` e deixe **Public**.
4. Crie o repositório.
5. Toque em **Add file** → **Upload files**.
6. Envie `index.html` deste pacote e confirme em **Commit changes**.
7. Abra **Settings** → **Pages**.
8. Em **Build and deployment**, escolha **Deploy from a branch**.
9. Selecione `main` e `/ (root)`, depois **Save**.
10. Aguarde a publicação. O endereço será `https://SEU-USUARIO.github.io/nexus-cloud/`.

## Limitações desta primeira versão
É apenas a interface pública. Não há login real, banco de dados, cobrança Pix, painel administrativo seguro ou máquinas Android. GitHub Pages não executa backend. Esses recursos exigem backend/API e um provedor de Cloud Phone real. Os preços são exemplos e não devem ser cobrados até que o serviço esteja operacional.
